package com.capg.bank.ui;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

import com.capg.bank.bean.Customer;
import com.capg.bank.service.BankImplementationService;

public class Main {

	public static void main(String[] args) throws IOException {
		long accNo = 0;

		BankImplementationService service = new BankImplementationService();
		do {
			System.out.println("1.Create Account");
			System.out.println("2.Show Balance");
			System.out.println("3.Deposit");
			System.out.println("4.Withdraw");
			System.out.println("5.Fund Transfer");
			System.out.println("6.Print Transactions");

			Scanner sc = new Scanner(System.in);
			int choice = sc.nextInt();

			BufferedReader br = new BufferedReader(new InputStreamReader(
					System.in));

			switch (choice) {
			case 1:
				Customer cust = new Customer();
				System.out.println("Enter the name");
				String name;
				do {
					name = sc.next();
				} while (!service.isValidName(name));

				cust.setName(name);
				System.out.println("Enter the Address");
				String address;
				address = br.readLine();
				cust.setAddress(address);

				System.out.println("Enter the AatharNo ");
				String aathar;
				do {
					aathar = sc.next();
				} while (!service.isValidAathar(aathar));
				cust.setAathar(aathar);

				System.out.println("Enter the phone Number");
				String phoneNo;
				do {
					phoneNo = sc.next();
				} while (!service.isValidPhone(phoneNo));
				cust.setPhoneNo(phoneNo);

				accNo = (long) (Math.random() * 700000);
				System.out.println("Account Number" + accNo);
				cust.setAccNo(accNo);

				System.out.println("Account created successfully");
				service.createAccount(cust, accNo);
				break;

			case 2:

				System.out.println("Enter the account number for getting the balance");
				long id1 = sc.nextLong();
				long s = service.validAccount(id1);
				if (s == id1) {
					System.out.println("balance= " + service.showBalance(id1));
				} 
				else
					System.out.println("Enter the correct account number");

				break;

			case 3:
				System.out
						.println("Enter the account number for getting the balance");
				long id2 = sc.nextLong();
				long s1 = service.validAccount(id2);
				if (s1 == id2) {
					System.out.println("balance= " + service.showBalance(id2));
					System.out.println("Enter the amount to be deposited");
					double deposit = sc.nextDouble();
					System.out.println("balance="+ service.deposit(id2, deposit));
				} 
				else
					System.out.println("Enter the correct account number");

				break;

			case 4:
				System.out
						.println("Enter the account number for getting the balance");
				long id3 = sc.nextLong();
				long s2 = service.validAccount(id3);
				
				if (s2 == id3) {
					System.out.println("balance= " + service.showBalance(id3));
					System.out.println("Enter the amount to be withdrawn");
					double withdraw = sc.nextDouble();
					System.out.println("balance="+ service.withdraw(id3, withdraw));
				}
				else
					System.out.println("Enter the correct account number");

				break;

			case 5:
				System.out
						.println("Enter the first account number for getting the balance");
				long id4 = sc.nextLong();
				long s3 = service.validAccount(id4);
				System.out
						.println("Enter the second account number for getting the balance");
				long id5 = sc.nextLong();
				long s4 = service.validAccount(id5);

				if ((s3 == id4) && (s4 == id5)) {
					System.out.println("Enter the amount to be withdrawn");
					double transfer = sc.nextDouble();
					service.withdraw(id4, transfer);
					System.out.println("balance for" + id4 + "\t"+ service.showBalance(id4));

					service.deposit(id5, transfer);
					System.out.println("balance for " + id5 + "\t"+ service.showBalance(id5));
					service.fundTransfer(id4, id5, transfer);
				}
				else
					System.out.println("Enter the correct account number");

				break;

			case 6:
				System.out.println("Enter the account number");
				long id6 = sc.nextLong();
				long s5 = service.validAccount(id6);
				if (s5 == id6)
					System.out.println(service.printTransactions(id6));
				else
					System.out.println("Enter the correct account number");
				break;

			}
			// sc.close();
		} while (true);

	}

}
