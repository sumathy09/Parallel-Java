package com.capg.bank.bean;

public class Customer {
private String name;
private String phoneNo;
private String address;
private String aathar;
public long accNo;
private double balance;
public String transHistory;
public String getName() {
	return name;
}
public void setName(String name) {
    this.name = name;
}
public String getPhoneNo() {
    return phoneNo;
}
public void setPhoneNo(String phoneNo) {
    this.phoneNo = phoneNo;
}
public String getAddress() {
    return address;
}
public void setAddress(String address) {
    this.address = address;
}
 
public  String getAathar() {
    return aathar;
}
public void setAathar(String aathar2) {
    this.aathar = aathar2;
}

public long getAccNo() {
    return accNo;
}
public void setAccNo(long accNo) {
    this.accNo = accNo;
}

public double getBalance() {
    return (long) balance;
}
public double setBalance(double bal) {
    
    return this.balance=bal;
}
@Override
public String toString() {
    return "Customer [name=" + name + ", phoneNo=" + phoneNo + ", address="
            + address + ", aathar=" + aathar
              + ", balance=" + balance + "]"+"\n";
}
public String CustomerTransaction(String tran)
{
    if(this.transHistory==null)
        this.transHistory="";
    return this.transHistory=this.transHistory+tran;
}

}