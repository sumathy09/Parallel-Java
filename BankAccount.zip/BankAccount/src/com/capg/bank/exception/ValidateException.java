package com.capg.bank.exception;

public class ValidateException extends Exception {
public void ValidateException(){
	//super();
System.out.println("exception");

}

}
