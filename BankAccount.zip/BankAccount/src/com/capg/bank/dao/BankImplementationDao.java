 package com.capg.bank.dao;

import java.util.HashMap;
import java.util.Map;
import com.capg.bank.bean.Customer;

public class BankImplementationDao implements BankInterfaceDao {
      
    long accNo;
    Customer c = new Customer();
    double balance;
    long equal = 0L;

    Map<Long, Customer> map = new HashMap<Long, Customer>();
     
    @Override
    public Customer createAccount(Customer cust, long acNo) {
        // System.out.println(map.get(accNo));
        map.put(acNo, cust);
        System.out.println(map);
        
        return map.put(acNo, cust);
    }

    @Override
    public double showBalance(long id) {
        c = map.get(id);
        // for(Long id:map.keySet()){
        balance = c.getBalance();
        return balance;

    }

    @Override
    public double deposit(long id, double deposit) {
        // Customer c=new Customer();
        String tran="";
        c = map.get(id);
        balance = c.getBalance();
        tran="Money Deposited-"+ deposit +"";
        balance = balance + deposit;
        tran=tran+"\n"+"Updated Balance-" +balance+"\n";
        c.CustomerTransaction(tran);
        c.setBalance(balance);
        map.put(id, c);
     
         

        return balance;
    }

    @Override
    public double withdraw(long id, double withdraw) {
        // Customer c=new Customer();
        String tran="";
        c = map.get(id);
        tran="Amount Withdrawn-"+ withdraw +"";
        balance = c.getBalance();
        balance = balance - withdraw;
        tran=tran+"\n"+"Balance After Withdrawl-"+balance+"\n";
        c.CustomerTransaction(tran);
        c.setBalance(balance);
        map.put(id, c);
    //    Customer e = maps.put(id, c);
        return balance;

    }

    @Override
    public double fundTransfer(long ida, long idb, double transfer) {
        return balance;
    }

    @Override
    public String printTransactions(long id) {
        String tran="";
        c = map.get(id);
        tran=c.transHistory;
        tran+="\n"+"Current Balance--"+"\n"+c.getBalance();
        return tran;
    }

    public long validAccount(long id) {
        long equal = 0;
        if (map.containsKey(id)) {
            equal = id;
        }
        return equal;
    }
    
    
    
}
