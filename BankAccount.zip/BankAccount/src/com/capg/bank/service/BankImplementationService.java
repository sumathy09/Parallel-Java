 package com.capg.bank.service;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capg.bank.bean.Customer;
import com.capg.bank.dao.BankImplementationDao;

public class BankImplementationService implements BankInterfaceService {
    Scanner sc = new Scanner(System.in);

    BankImplementationDao dao = new BankImplementationDao();
    Customer cust = new Customer();

    @Override
    public Customer createAccount(Customer cust, long acNo) {
        return dao.createAccount(cust, acNo);
    }

    @Override
    public double showBalance(long id) {
        return dao.showBalance(id);
    }

    @Override
    public double deposit(long id, double deposit) {
        return dao.deposit(id, deposit);
    }

    @Override
    public double withdraw(long id, double withdraw) {
        return dao.withdraw(id, withdraw);
    }

    @Override
    public double fundTransfer(long ida, long idb, double transfer) {
        return dao.fundTransfer(ida, idb, transfer);

    }

    @Override
    public String printTransactions(long id) {
        return dao.printTransactions(id);

    }

    public boolean isValidName(String name) {

        Pattern p = Pattern.compile("[A-Za-z]{3,25}");
        Matcher mat = p.matcher(name);
        boolean s = mat.find();
        if (!s) {
            System.out.println("Name starts with captital");
        }
        return s;
    }

    public boolean isValidPhone(String phoneNo) {
        Pattern p = Pattern.compile("[0-9][0-9]{9}");
        Matcher mat = p.matcher(phoneNo);
        boolean s = mat.find();
        if (!s) {
            System.out.println("Enter 10 digits");
        }
        return s;
    }

    public boolean isValidAathar(String aathar) {
        Pattern p = Pattern.compile("[0-9]{12}");
        Matcher mat = p.matcher(aathar);
        boolean s = mat.find();
        if (!s) {
            System.out.println("Enter 12 digits");
        }
        return s;
    }

    public long validAccount(long id) {
        return dao.validAccount(id);
    }
    
}