package com.capg.bank.service;

import com.capg.bank.bean.Customer;

public interface BankInterfaceService {
	 Customer createAccount(Customer cust,long acNo);
	    double showBalance(long id);
	    double deposit(long id,double deposit);
	    double withdraw(long id,double withdraw);
	    double fundTransfer(long ida,long idb,double transfer);
	    String printTransactions(long id);
}
